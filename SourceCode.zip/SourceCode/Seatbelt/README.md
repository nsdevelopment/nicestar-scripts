# Seatbelt

Adds a seatbelt for front seat passengers. If seatbelt is not enabled, being involved in a crash may cause ejection. Sound effects for buckling and unbuckling, as well as the reminder chime.

Keybinds:
- `Y` To toggle the seatbelt when in the front seat. No controller support.
