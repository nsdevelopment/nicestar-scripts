﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Seatbelt.Client")]
[assembly: Guid("38170d58-8eb0-40ec-a80f-c0fbec94dd7c")]