﻿using CitizenFX.Core;
using CitizenFX.Core.Native;
using CitizenFX.Core.UI;
using NS.Fivem.Common.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NS.Fivem.Seatbelt.Client
{
    public class Client : ClientScript
    {
        protected bool seatbeltEnabled, wasInCar, hudHidden;
        protected bool seatbeltChimeEnabled = true;
        protected bool passUpdate = false;
        protected int controlPressed = 0;
        protected float[] speedBuffer = new float[2];
        protected Vector3[] velBuffer = new Vector3[2];
        protected readonly IReadOnlyList<VehicleClass> ignoredClasses = new List<VehicleClass> { VehicleClass.Cycles, VehicleClass.Trains, VehicleClass.Motorcycles };

        public Client()
        {
            API.DecorRegister("SeatbeltBuckled", 2);
        }

        [Tick]
        internal async Task SeatbeltControls()
        {
            if (seatbeltEnabled)
            {
                Game.DisableControlThisFrame(0, Control.VehicleExit);
                Game.DisableControlThisFrame(27, Control.VehicleExit);

                if (Controls.IsControlJustPressedRegardless(Control.VehicleExit))
                {
                    if (controlPressed > 0 && (Game.GameTime - controlPressed) < 500)
                    {
                        Debug.WriteLine("Double press of vehicle exit, exiting");
                        seatbeltEnabled = false;
                        Game.PlayerPed.Task.LeaveVehicle();
                        controlPressed = 0;
                    }
                    else
                    {
                        if (controlPressed > 0)
                        {
                            Screen.ShowNotification("Your seatbelt is on. Press ~y~Y ~w~to unbuckle.");
                        }
                        controlPressed = Game.GameTime;
                    }
                }
            }

            if (Controls.IsKeyJustPressed(Controls.Keys.Y) && VehicleCheck(Game.PlayerPed.CurrentVehicle) && !Game.PlayerPed.IsBeingStunned)
            {
                ChangeSeatbelt();
                await Delay(1500);
            }
        }

        [Tick]
        internal async Task SeatbeltTick()
        {
            Ped player = Game.PlayerPed;
            Vehicle veh = player.CurrentVehicle;

            bool hudCheck = API.IsHudHidden() || API.IsPauseMenuActive();

            if (hudCheck && !hudHidden)
            {
                hudHidden = hudCheck;
                API.SendNuiMessage($"{{\"hud\":false}}");
                await Delay(100);
                return;
            }
            else if (!hudCheck && hudHidden)
            {
                hudHidden = hudCheck;
                API.SendNuiMessage($"{{\"hud\":true}}");
                await Delay(100);
                return;
            }

            if (Entity.Exists(veh) && veh.Driver != player && veh.GetPedOnSeat(VehicleSeat.Passenger) != player)
            {
                if (!passUpdate)
                {
                    Cleanup();
                    passUpdate = true;
                }

                await Delay(250);
                return;
            }
            passUpdate = false;

            if (VehicleCheck(veh) && !player.IsBeingStunned)
            {
                if (!wasInCar)
                {
                    wasInCar = true;
                    SendNUIUpdate();
                    if (player.IsSittingInVehicle() || player.IsGettingIntoAVehicle)
                    {
                        Screen.DisplayHelpTextThisFrame("Press ~INPUT_MP_TEXT_CHAT_TEAM~ to buckle your seatbelt");
                    }
                }

                if (!seatbeltEnabled && veh.Driver == player)
                {
                    if (veh.Speed > 7f && seatbeltChimeEnabled)
                    {
                        API.SendNuiMessage($"{{\"shouldChime\":true}}");
                    }
                    else
                    {
                        API.SendNuiMessage($"{{\"shouldChime\":false}}");
                    }
                }

                speedBuffer[1] = speedBuffer[0];
                speedBuffer[0] = veh.Speed;

                float speedDiff = speedBuffer[1] - speedBuffer[0];

                if (!seatbeltEnabled && speedBuffer[1] > 26.0f && API.GetEntitySpeedVector(veh.Handle, true).Y > -5f && speedDiff > 0.0f && speedDiff > (speedBuffer[1] * 0.3f))
                {
                    Debug.WriteLine($"Seatbelt not buckled. Ejecting. Speed Difference {Math.Round(speedDiff, 3)}. Needed: {Math.Round(speedBuffer[1] * 0.3, 3)}");
                    Debug.WriteLine($"Setting player health to: {(player.HealthFloat * 0.8f)}");
                    player.HealthFloat *= 0.8f;
                    veh.IsPersistent = true;
                    veh.Windows[VehicleWindowIndex.ExtraWindow3].Smash();
                    Vector3 coords = player.Position;
                    Vector3 fw = ForwardVelocity(player);
                    player.Task.LeaveVehicle(LeaveVehicleFlags.WarpOut);
                    await Delay(5);
                    player.Position = new Vector3(coords.X + fw.X, coords.Y + fw.Y, coords.Z + fw.Z);
                    player.Velocity = new Vector3(velBuffer[1].X, velBuffer[1].Y, velBuffer[1].Z);
                    await Delay(10);
                    player.Ragdoll(3000);
                    return;
                }

                velBuffer[1] = velBuffer[0];
                velBuffer[0] = veh.Velocity;
            }
            else if (wasInCar || player.IsBeingStunned)
            {
                await Delay(100);
                Cleanup();
            }

            await Delay(10);
        }

        private void Cleanup()
        {
            seatbeltEnabled = false;
            wasInCar = false;
            speedBuffer[0] = speedBuffer[1] = 0f;
            SendNUIUpdate();
            TriggerEvent("NS:seatbelt", seatbeltEnabled);
        }

        [EventHandler("NS:Seatbelt:ToggleChime")]
        private void ToggleChime(bool chimeToggle) => seatbeltChimeEnabled = chimeToggle;

        [EventHandler("NS:changeSeatbelt")]
        internal void ChangeSeatbelt()
        {
            seatbeltEnabled = !seatbeltEnabled;
            API.DecorSetBool(Game.PlayerPed.Handle, "SeatbeltBuckled", seatbeltEnabled);
            Screen.ShowNotification("Seatbelt ~y~" + (seatbeltEnabled ? "buckled" : "unbuckled"));
            API.SendNuiMessage($"{{\"belt\":{seatbeltEnabled.ToString().ToLower()}, \"car\":true}}");
            TriggerEvent("NS:seatbelt", seatbeltEnabled);
        }

        private void SendNUIUpdate() => API.SendNuiMessage($"{{\"belt\":{seatbeltEnabled.ToString().ToLower()}, \"car\":{wasInCar.ToString().ToLower()}}}");

        private Vector3 ForwardVelocity(Ped player)
        {
            float hdg = player.Heading + 90f;
            if (hdg < 0)
            {
                hdg += 360f;
            }

            hdg *= 0.0174533f;

            return new Vector3((float)Math.Cos(hdg) * 2f, (float)Math.Sin(hdg) * 2f, 0f);
        }

        private bool VehicleCheck(Vehicle veh) => Entity.Exists(veh) && veh.Model.IsCar && !ignoredClasses.Contains(veh.ClassType);
    }
}
