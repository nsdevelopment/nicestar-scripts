using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// This file is shared by all projects.

[assembly: AssemblyCopyright("Copyright 2024 NS")]
[assembly: AssemblyCompany("NiceStar")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: ComVisible(false)]
