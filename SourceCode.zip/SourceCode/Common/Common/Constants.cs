﻿namespace NS.Fivem.Common
{
    public static class Constants
    {
        public const string DEBUG_LOG_PREFIX = "[NS - DEBUG]: ";
        public const string LOG_PREFIX = "[NS]: ";
    }

    public static class Animations
    {
        public class Dictionary
        {
            public const string HANDS_UP = "random@getawaydriver";
            public const string HANDS_UP_KNEES = "random@getawaydriver";

            public const string HAND_ON_HOLSTER = "reaction@intimidation@cop@unarmed";
            public const string HOLSTER = "rcmjosh4";
        }

        public class Name
        {
            public const string HANDS_UP = "idle_2_hands_up";
            public const string HANDS_UP_KNEES = "idle_a";

            public const string HAND_ON_HOLSTER = "intro";
            public const string HOLSTER = "josh_leadout_cop2";
        }
    }

    public static class Event
    {
        private const string PREFIX_CLIENT = "NS:Client:";
        private const string PREFIX_SERVER = "NS:Server:";

        public class Client
        {
            //public const string EXAMPLE_EVENT = PrefixClient + "ExampleEvent";

            // Chat Client Events
            public const string CHAT_CLEAR = "chat:clear";
            public const string CHAT_DISPLAY_MESSAGE = "chat:addMessage";
        }

        public class Server
        {
            public const string DEBUG_LOG = PREFIX_SERVER + "DebugLog";
            public const string LOG = PREFIX_SERVER + "Log";

            //public const string EXAMPLE_EVENT = PrefixServer + "ExampleEvent";
            public const string DROP_PLAYER = PREFIX_SERVER + "DropPlayer";

            // FiveM Server Events
            public const string FIVEM_CHAT_MESSAGE = "chatMessage";
            public const string FIVEM_ENTERED_VEHICLE = "enteredVehicle";
            public const string FIVEM_ABORTED_VEHICLE = "enteringAborted";
            public const string FIVEM_ENTERING_VEHICLE = "enteringVehicle";
            public const string FIVEM_EXITED_VEHICLE = "leftVehicle";
            public const string FIVEM_GAME_TYPE_START = "onGameTypeStart";
            public const string FIVEM_GAME_TYPE_STOP = "onGameTypeStop";
            public const string FIVEM_MAP_START = "onMapStart";
            public const string FIVEM_MAP_STOP = "onMapStop";
            public const string FIVEM_PLAYER_KILLED = "onPlayerKilled";
            public const string FIVEM_RESOURCE_START = "onResourceStart";
            public const string FIVEM_RESOURCE_STARTING = "onResourceStarting";
            public const string FIVEM_RESOURCE_STOP = "onResourceStop";
            public const string FIVEM_PLAYER_CONNECTING = "playerConnecting";
            public const string FIVEM_PLAYER_DROPPED = "playerDropped";
            public const string FIVEM_RCON_COMMAND = "rconCommand";
            public const string FIVEM_PLAYER_SPAWNED = "playerSpawned";
        }
    }
}
