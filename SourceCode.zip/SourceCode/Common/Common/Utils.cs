﻿using System.Collections.Generic;

namespace NS.Fivem.Common
{
    public static class Utils
    {
        public static T GetVal<T>(this IDictionary<string, object> dict, string key, T defaultVal)
        {
            if (dict.ContainsKey(key) && dict[key] is T)
                    return (T)dict[key];

            return defaultVal;
        }
    }
}
