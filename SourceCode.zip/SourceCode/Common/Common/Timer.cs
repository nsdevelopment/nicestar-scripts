﻿using System;
using System.Threading.Tasks;

namespace NS.Fivem.Common
{
    /*
    public class Timer
    {
        private TimeSpan timeFrame;
        private bool interrupted;

        public Timer(TimeSpan _timeFrame)
        {
            timeFrame = _timeFrame;
        }

        public async Task<bool> Run()
        {
            var start = DateTime.UtcNow;
            var end = start.Add(timeFrame);
            return await Task.FromResult<bool>(DateTime.UtcNow >= end || interrupted);
        }

        public void Stop()
        {
            interrupted = true;
        }
    }*/
}
