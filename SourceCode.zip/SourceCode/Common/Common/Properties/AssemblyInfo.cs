﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Common")]
[assembly: Guid("106e31c0-7fd2-4766-947a-ec379cd23911")]
