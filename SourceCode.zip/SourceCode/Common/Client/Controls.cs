﻿using CitizenFX.Core;
using CitizenFX.Core.Native;

namespace NS.Fivem.Common.Client
{
    public class Controls : BaseScript
    {
        #region Keys
        public enum Keys
        {
            ESC = 322, F1 = 288, F2 = 289, F3 = 170, F5 = 166, F6 = 167, F7 = 168, F8 = 169, F9 = 56, F10 = 57,
            TILDE = 243, ONE = 157, TWO = 158, THREE = 160, FOUR = 164, FIVE = 165, SIX = 159, SEVEN = 161, EIGHT = 162, NINE = 163, MINUS = 84, EQUAL = 83, BACKSPACE = 194,
            TAB = 37, Q = 44, W = 32, E = 38, R = 45, T = 245, Y = 246, U = 303, P = 199, OPENBRACKET = 39, CLOSEBRACKET = 40, ENTER = 18,
            CAPS = 137, A = 34, S = 8, D = 9, F = 23, G = 47, H = 74, K = 311, L = 182,
            LEFTSHIFT = 21, Z = 20, X = 73, C = 26, V = 0, B = 29, N = 249, M = 244, COMMA = 82, PERIOD = 81,
            LEFTCTRL = 36, LEFTALT = 19, SPACE = 22, RIGHTCTRL = 70,
            HOME = 213, PAGEUP = 316, PAGEDOWN = 317, DELETE = 178,
            LEFT = 174, RIGHT = 175, TOP = 27, DOWN = 173,
            NENTER = 201, N4 = 108, N5 = 60, N6 = 107, NADD = 96, NMINUS = 97, N7 = 117, N8 = 61, N9 = 118
        }
        /// <summary>
        /// Returns if the specified enabled key was just pressed on the keyboard/mouse.
        /// </summary>
        public static bool IsKeyJustPressed(Keys k, int inputGroup = 0) => 
            Game.IsControlJustPressed(inputGroup, (Control)k) && Game.CurrentInputMode == InputMode.MouseAndKeyboard && API.UpdateOnscreenKeyboard() != 0;

        /// <summary>
        /// Returns if the specified enabled key was just pressed on the keyboard/mouse.
        /// </summary>
        public static bool IsKeyJustPressed(int k, int inputGroup = 0) =>
            Game.IsControlJustPressed(inputGroup, (Control)k) && Game.CurrentInputMode == InputMode.MouseAndKeyboard && API.UpdateOnscreenKeyboard() != 0;

        /// <summary>
        /// Returns if the specified enabled key is pressed on the keyboard/mouse.
        /// </summary>
        public static bool IsKeyPressed(Keys k, int inputGroup = 0) =>
            Game.IsControlPressed(inputGroup, (Control)k) && Game.CurrentInputMode == InputMode.MouseAndKeyboard && API.UpdateOnscreenKeyboard() != 0;

        /// <summary>
        /// Returns if the specified enabled key is pressed on the keyboard/mouse.
        /// </summary>
        public static bool IsKeyPressed(int k, int inputGroup = 0) =>
            Game.IsControlPressed(inputGroup, (Control)k) && Game.CurrentInputMode == InputMode.MouseAndKeyboard && API.UpdateOnscreenKeyboard() != 0;

        /// <summary>
        /// Returns if the specified key was just pressed on the keyboard/mouse, even if the control is disabled.
        /// </summary>
        public static bool IsKeyJustPressedRegardless(Keys k, int inputGroup = 0) => IsControlJustPressedRegardless((Control)k, inputGroup) && Game.CurrentInputMode == InputMode.MouseAndKeyboard;

        /// <summary>
        /// Returns if the specified key was just pressed on the keyboard/mouse, ONLY if the control is disabled.
        /// </summary>
        public static bool IsDisabledKeyJustPressed(Keys k, int inputGroup = 0) => IsDisabledControlJustPressed((Control)k, inputGroup) && Game.CurrentInputMode == InputMode.MouseAndKeyboard;

        /// <summary>
        /// Returns if the specified key is pressed on the keyboard/mouse, even if the control is disabled.
        /// </summary>
        public static bool IsKeyPressedRegardless(Keys k, int inputGroup = 0) => IsControlPressedRegardless((Control)k, inputGroup) && Game.CurrentInputMode == InputMode.MouseAndKeyboard;

        /// <summary>
        /// Returns if the specified key is pressed on the keyboard/mouse, ONLY if the control is disabled.
        /// </summary>
        public static bool IsDisabledKeyPressed(Keys k, int inputGroup = 0) => IsDisabledControlPressed((Control)k, inputGroup) && Game.CurrentInputMode == InputMode.MouseAndKeyboard;

        /// <summary>
        /// Returns if the specified key was just pressed on the keyboard/mouse, even if the control is disabled.
        /// </summary>
        public static bool IsKeyJustPressedRegardless(int k, int inputGroup = 0) => IsControlJustPressedRegardless((Control)k, inputGroup) && Game.CurrentInputMode == InputMode.MouseAndKeyboard;

        /// <summary>
        /// Returns if the specified key is pressed on the keyboard/mouse, even if the control is disabled.
        /// </summary>
        public static bool IsKeyPressedRegardless(int k, int inputGroup = 0) => IsControlPressedRegardless((Control)k, inputGroup) && Game.CurrentInputMode == InputMode.MouseAndKeyboard;

        /// <summary>
        /// Returns if the specified key was just pressed on the keyboard/mouse, ONLY if the control is disabled.
        /// </summary>
        public static bool IsDisabledKeyJustPressed(int k, int inputGroup = 0) => IsDisabledControlJustPressed((Control)k, inputGroup) && Game.CurrentInputMode == InputMode.MouseAndKeyboard;

        /// <summary>
        /// Returns if the specified key is pressed on the keyboard/mouse, ONLY if the control is disabled.
        /// </summary>
        public static bool IsDisabledKeyPressed(int k, int inputGroup = 0) => IsDisabledControlPressed((Control)k, inputGroup) && Game.CurrentInputMode == InputMode.MouseAndKeyboard;

        // pseudo way to check if a key is held... not too sure how well it'll work.
        /*public static async Task<bool> IsKeyHeld(Keys c, int inputGroup = 0)
        {
            if (Game.CurrentInputMode == InputMode.MouseAndKeyboard && Game.IsControlPressed(inputGroup, (Control)c))
            {
                await new Timer(new System.TimeSpan(0, 0, 2)).Run();

                if (Game.CurrentInputMode == InputMode.MouseAndKeyboard && Game.IsControlPressed(inputGroup, (Control)c))
                {
                    return true;
                }
            }

            return false;
        }*/
        #endregion

        #region Controls
        /// <summary>
        /// Returns if the specified control was just pressed, even if the control is disabled.
        /// </summary>
        public static bool IsControlJustPressedRegardless(Control c, int inputGroup = 0) =>
            (Game.IsControlJustPressed(inputGroup, c) || Game.IsDisabledControlJustPressed(inputGroup, c)) && API.UpdateOnscreenKeyboard() != 0;

        /// <summary>
        /// Returns if the specified control was just pressed, ONLY if the control is disabled.
        /// </summary>
        public static bool IsDisabledControlJustPressed(Control c, int inputGroup = 0) =>
            Game.IsDisabledControlJustPressed(inputGroup, c) && API.UpdateOnscreenKeyboard() != 0;

        /// <summary>
        /// Returns if the specified control is pressed, even if the control is disabled.
        /// </summary>
        public static bool IsControlPressedRegardless(Control c, int inputGroup = 0) =>
            (Game.IsControlPressed(inputGroup, c) || Game.IsDisabledControlPressed(inputGroup, c)) && API.UpdateOnscreenKeyboard() != 0;

        /// <summary>
        /// Returns if the specified control is pressed, ONLY if the control is disabled.
        /// </summary>
        public static bool IsDisabledControlPressed(Control c, int inputGroup = 0) =>
            Game.IsDisabledControlPressed(inputGroup, c) && API.UpdateOnscreenKeyboard() != 0;

        /// <summary>
        /// Returns if the specified control was just pressed, either on k&m or controller.
        /// </summary>
        public static bool IsControlJustPressed(Control c, int inputGroup = 0) =>
            (Game.IsControlJustPressed(inputGroup, c) || Game.IsDisabledControlJustPressed(inputGroup, c)) && API.UpdateOnscreenKeyboard() != 0;

        /// <summary>
        /// Returns if the specified control is pressed, either on k&m or controller.
        /// </summary>
        public static bool IsControlPressed(Control c, int inputGroup = 0) =>
            Game.IsControlPressed(inputGroup, c) && API.UpdateOnscreenKeyboard() != 0;

        // pseudo way to check if a key is held... not too sure how well it'll work.
        /* public static async Task<bool> IsKeyHeld(Control c, int inputGroup = 0)
         {
             if (Game.IsControlPressed(inputGroup, c))
             {
                 await new Timer(new System.TimeSpan(0, 0, 2)).Run();

                 if (Game.IsControlPressed(inputGroup, c))
                 {
                     return true;
                 }
             }

             return false;
         }*/
        #endregion

        #region Buttons
        public enum Buttons
        {
            XBoxA = 191,
            XBoxB = 194,
            XBoxY = 192,
            XBoxX = 193,
            DpadLeft = 189,
            DpadRight = 190,
            DpadUp = 188,
            DpadDown = 187,
            RT = 228,
            LT = 229,
            LB = 226,
            RB = 227,
            L3 = 230,
            R3 = 231,
            SELECT,
            PAUSE = 199,
            /* Not sure on these
            LSUP,
            LSDOWN,
            LSLEFT,
            LSRIGHT,
            RSUP,
            RSDOWN,
            RSLEFT,
            RSRIGHT,*/
            PsX = XBoxA,
            PsCircle = XBoxB,
            PsSquare = XBoxX,
            PsTriangle = XBoxY,
            L2 = LB,
            R2 = RB
        }

        public static bool IsButtonJustPressed(Buttons b, int inputGroup = 0) =>
            Game.IsControlJustPressed(inputGroup, (Control)b) && Game.CurrentInputMode == InputMode.GamePad;

        /// <summary>
        /// Returns if the specified enabled control was just pressed on a controller.
        /// </summary>
        public static bool IsButtonJustPressed(int b, int inputGroup = 0) =>
            Game.IsControlJustPressed(inputGroup, (Control)b) && Game.CurrentInputMode == InputMode.GamePad;

        /// <summary>
        /// Returns if the specified enabled control is pressed on a controller.
        /// </summary>
        public static bool IsButtonPressed(Buttons b, int inputGroup = 0) =>
            Game.IsControlPressed(inputGroup, (Control)b) && Game.CurrentInputMode == InputMode.GamePad;

        /// <summary>
        /// Returns if the specified enabled control is pressed on a controller.
        /// </summary>
        public static bool IsButtonPressed(int b, int inputGroup = 0) =>
            Game.IsControlPressed(inputGroup, (Control)b) && Game.CurrentInputMode == InputMode.GamePad;

        /// <summary>
        /// Returns if the specified control was just pressed on a controller, even if the control is disabled.
        /// </summary>
        public static bool IsButtonJustPressedRegardless(Buttons b, int inputGroup = 0) => IsControlJustPressedRegardless((Control)b, inputGroup) && Game.CurrentInputMode == InputMode.GamePad;

        /// <summary>
        /// Returns if the specified control was just pressed on a controller, ONLY if the control is disabled.
        /// </summary>
        public static bool IsDisabledButtonJustPressed(Buttons b, int inputGroup = 0) => IsDisabledControlJustPressed((Control)b, inputGroup) && Game.CurrentInputMode == InputMode.GamePad;

        /// <summary>
        /// Returns if the specified control is pressed on a controller, even if the control is disabled.
        /// </summary>
        public static bool IsButtonPressedRegardless(Buttons b, int inputGroup = 0) => IsControlPressedRegardless((Control)b, inputGroup) && Game.CurrentInputMode == InputMode.GamePad;

        /// <summary>
        /// Returns if the specified control is pressed on a controller, ONLY if the control is disabled.
        /// </summary>
        public static bool IsDisabledButtonPressed(Buttons b, int inputGroup = 0) => IsDisabledControlPressed((Control)b, inputGroup) && Game.CurrentInputMode == InputMode.GamePad;

        /// <summary>
        /// Returns if the specified control was just pressed on a controller, even if the control is disabled.
        /// </summary>
        public static bool IsButtonJustPressedRegardless(int b, int inputGroup = 0) => IsControlJustPressedRegardless((Control)b, inputGroup) && Game.CurrentInputMode == InputMode.GamePad;

        /// <summary>
        /// Returns if the specified control is pressed on a controller, even if the control is disabled.
        /// </summary>
        public static bool IsDisabledButtonPressed(int b, int inputGroup = 0) => IsDisabledControlPressed((Control)b, inputGroup) && Game.CurrentInputMode == InputMode.GamePad;

        /// <summary>
        /// Returns if the specified control is pressed on the keyboard/mouse, even if the control is disabled.
        /// </summary>
        public static bool IsDisabledButtonRegardless(Buttons b, int inputGroup = 0) => IsDisabledControlPressed((Control)b, inputGroup) && Game.CurrentInputMode == InputMode.GamePad;

        // pseudo way to check if a key is held... not too sure how well it'll work.
        /*public static async Task<bool> IsKeyHeld(Button c, int inputGroup = 0)
        {
            if (Game.CurrentInputMode == InputMode.GamePad && Game.IsControlPressed(inputGroup, (Control)c))
            {
                await new Timer(new System.TimeSpan(0, 0, 2)).Run();

                if (Game.CurrentInputMode == InputMode.GamePad && Game.IsControlPressed(inputGroup, (Control)c))
                {
                    return true;
                }
            }

            return false;
        }*/
        #endregion

        public enum InputGroups
        {
            UNK = -1,
            MOVE = 0, // COMMON
            LOOK = 1, // COMMON
            WHEEL = 2, // COMMON
            CELLPHONE_NAVIGATE = 3,
            CELLPHONE_NAVIGATE_UD = 4,
            CELLPHONE_NAVIGATE_LR = 5,
            FRONTEND_DPAD_ALL = 6,
            FRONTEND_DPAD_UD = 7,
            FRONTEND_DPAD_LR = 8,
            FRONTEND_LSTICK_ALL = 9,
            FRONTEND_RSTICK_ALL = 10,
            FRONTEND_GENERIC_UD = 11,
            FRONTEND_GENERIC_LR = 12,
            FRONTEND_GENERIC_ALL = 13,
            FRONTEND_BUMPERS = 14,
            FRONTEND_TRIGGERS = 15,
            FRONTEND_STICKS = 16,
            SCRIPT_DPAD_ALL = 17,
            SCRIPT_DPAD_UD = 18,
            SCRIPT_DPAD_LR = 19,
            SCRIPT_LSTICK_ALL = 20,
            SCRIPT_RSTICK_ALL = 21,
            SCRIPT_BUMPERS = 22,
            SCRIPT_TRIGGERS = 23,
            WEAPON_WHEEL_CYCLE = 24,
            FLY = 25,
            SUB = 26,
            VEH_MOVE_ALL = 27,
            CURSOR = 28,
            CURSOR_SCROLL = 29,
            SNIPER_ZOOM_SECONDARY = 30,
            VEH_HYDRAULICS_CONTROL = 31,
        }
    }
}
