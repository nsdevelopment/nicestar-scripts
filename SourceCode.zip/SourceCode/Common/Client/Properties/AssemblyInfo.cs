﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Common.Client")]
[assembly: Guid("320fd3a5-e1ec-49d6-b671-001026a80341")]
[assembly: AssemblyDescription("NS")]
[assembly: AssemblyProduct("Notes")]
