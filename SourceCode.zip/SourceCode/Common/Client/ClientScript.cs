﻿using CitizenFX.Core;
using CitizenFX.Core.UI;
using CitizenFX.Core.Native;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;

namespace NS.Fivem.Common.Client
{
    public abstract class ClientScript : BaseScript
    {
        #region Local Player References
        /// <summary>
        /// Gets the local player's Player
        /// </summary>
        public static Player ClientPlayer => Game.Player;

        /// <summary>
        /// Gets the local player's Character
        /// </summary>
        public static Ped ClientPed => Game.PlayerPed;

        /// <summary>
        /// Updated via event: EVENT_NS_CORE_CHARACTER_CHANGED
        /// Do not call this on tick. It is very expensive.
        /// </summary>
        public object ClientCharacter => Exports["GetCurrentCharacter"];
        #endregion

        #region Common Lists
        public static readonly IReadOnlyList<string> AcceptWords = new List<string>
        {
            "yes", "y", "1", "true", "accept", "a", "yep"
        };

        public static readonly IReadOnlyList<string> DenyWords = new List<string>
        {
            "no", "n", "0", "false", "deny", "d", "nope"
        };
        #endregion

        #region Vehicle References
        /// <summary>
        /// Gets the local player's current vehicle
        /// </summary>
        public static Vehicle ClientCurrentVehicle => ClientPed?.CurrentVehicle;

        /// <summary>
        /// Gets the local player's current vehicle if they are in one, otherwise the last vehicle they were in
        /// </summary>
        public static Vehicle ClientLastVehicle => ClientPed?.LastVehicle;

        /// <summary>
        /// Gets the closest vehicle entity to the client with a restricting radius.
        /// </summary>
        /// <param name="limitRadius">Maximum radius to search for a vehicle entity.</param>
        public static Vehicle GetClosestVehicleToClient(float limitRadius = 2.0f) => ClientPed.GetClosestVehicleToPed(limitRadius);
        #endregion


        /// <summary>
        /// Dictionary of callbacks currently being stored, run a callback with 
        /// </summary>
        protected internal CallbackHandlerDictionary CallbackHandlers { get; set; } = new CallbackHandlerDictionary();

        /// <summary>
        /// Triggers a server event that can be returned inline to a Delegate action
        /// </summary>
        /// <param name="eventName">The name of the event on the server</param>
        /// <param name="action">The Delegate or Func that will be invoked on return from the server</param>
        /// <param name="args">Any arguments to be passed to server event</param>
        public void TriggerServerCallback(string eventName, Delegate action, params object[] args)
        {
            string guid = RegisterCallbackInternal(action);
            TriggerServerEvent(eventName, guid, args);
        }

        /// <summary>
        /// Triggers a specific callback to the server
        /// </summary>
        /// <param name="guid">The GUID of the registered callback</param>
        /// <param name="args">Any other arguments</param>
        public void ReturnServerCallback(string guid, params object[] args)
        {
            TriggerServerEvent($"NScommon:server:internalcallback:{guid}", guid, args);
        }

        /// <summary>
        /// Internal method, registers a Delegate as a callback
        /// </summary>
        internal string RegisterCallbackInternal(Delegate action)
        {
            string guid = Guid.NewGuid().ToString();
            CallbackHandlers[guid] += action;
            EventHandlers.Add($"NScommon:client:internalcallback:{guid}", new Action<string, List<object>>(ReceiveInternalCallback));
            return guid;
        }

        /// <summary>
        /// This function will be added at run-time as an event handler for the server to call, should not be called directly.
        /// </summary>
        internal async void ReceiveInternalCallback(string guid, List<object> args)
        {
            await CallbackHandlers[guid].Invoke(args.ToArray());
            CallbackHandlers[guid].Destroy();
            CallbackHandlers.Remove(guid);
            EventHandlers.Remove($"NScommon:client:internalcallback:{guid}");
        }


        /// <summary>
        /// This function should be called when the client wants/needs to network a network ID.
        /// </summary>
        public static void SetNetworkIdNetworked(int netId)
        {
            API.SetNetworkIdExistsOnAllMachines(netId, true);
            API.SetNetworkIdCanMigrate(netId, true);
        }

        /// <summary>
        /// Returns whether the onscreen keyboard is active/in-use.
        /// </summary>
        public static bool IsOnScreenKeyboardActive() => API.UpdateOnscreenKeyboard() == 3;

        #region Audio References
        /// <summary>
        /// This function plays a game sound, before releasing the soundId when the sound has finished.
        /// </summary>
        public static async void PlayManagedSoundFrontend(string soundName, string soundSet = null)
        {
            int soundId = Audio.PlaySoundFrontend(soundName, soundSet);

            while (!Audio.HasSoundFinished(soundId))
            {
                await Delay(200);
            }

            Audio.ReleaseSound(soundId);
        }
        #endregion

        /// <summary>
        /// `.FromNetworkId()` but with extra checks and option to request control.
        /// </summary>
        /// <param name="networkId">Network ID of entity</param>
        /// <param name="networkControl">If you want to request control</param>
        /// <returns>Entity or null</returns>
        public static async Task<Entity> GetEntityFromNetwork(int networkId, bool networkControl = true)
        {
            if (networkId == 0 || !API.NetworkDoesNetworkIdExist(networkId))
            {
                Debug.WriteLine($"Could not request network ID {networkId} because it does not exist!");
                return null;
            }

            if (networkControl)
            {
                int timeout = 0;
                while (!API.NetworkHasControlOfNetworkId(networkId) && timeout < 4)
                {
                    timeout++;
                    API.NetworkRequestControlOfNetworkId(networkId);
                    await Delay(500);
                }

                if (!API.NetworkHasControlOfNetworkId(networkId))
                {
                    Debug.WriteLine($"Could not request control of network ID {networkId}.");
                    return null;
                }
            }

            return Entity.FromNetworkId(networkId);
        }

        public static class Hud
        {
            /// <summary>
            /// Should be called every frame to draw text on the screen.
            /// </summary>
            /// <param name="x">X location of text.</param>
            /// <param name="y">Y location of text.</param>
            /// <param name="scale">Size of text.</param>
            public static void DrawText2D(float x, float y, float scale, string text, int r, int g, int b, int a, Alignment alignment = Alignment.Left)
            {
                Minimap anchor = MinimapAnchor.GetMinimapAnchor();
                x = anchor.X + (anchor.Width * x);
                y = anchor.Y - y;

                API.SetTextFont(4);
                API.SetTextProportional(false);
                API.SetTextScale(scale, scale);
                API.SetTextColour(r, g, b, a);
                API.SetTextDropshadow(0, 0, 0, 0, 255);
                API.SetTextEdge(2, 0, 0, 0, 255);
                API.SetTextDropShadow();
                API.SetTextOutline();

                if (alignment == Alignment.Center)
                {
                    API.SetTextJustification(0);
                }
                else if (alignment == Alignment.Right)
                {
                    API.SetTextWrap(0, x);
                    API.SetTextJustification(2);
                }

                API.SetTextEntry("STRING");
                API.AddTextComponentString(text);
                API.DrawText(x, y);
            }

            /// <summary>
            /// Should be called every frame to draw text in the game world.
            /// </summary>
            /// <param name="pos">Location of text in the game world.</param>
            /// <param name="drawBackground">If a black box should be drawn behind the text to give it more contrast.</param>
            /// <param name="font">The font type to use for the text.</param>
            public static void DrawText3D(Vector3 pos, string text, bool drawBackground = true, int font = 4)
            {
                float screenX = 0f, screenY = 0f;
                API.World3dToScreen2d(pos.X, pos.Y, pos.Z, ref screenX, ref screenY);

                API.SetTextScale(0.35f, 0.35f);
                API.SetTextFont(font);
                API.SetTextProportional(true);
                API.SetTextColour(255, 255, 255, 215);
                API.SetTextEntry("STRING");
                API.SetTextCentre(true);
                API.AddTextComponentString(text);
                API.DrawText(screenX, screenY);
                if (drawBackground)
                {
                    API.DrawRect(screenX, screenY + 0.0125f, (float)text.Length / 300, 0.03f, 41, 11, 41, 68);
                }
            }

            public static void DrawImageNotification(string picture, int icon, string title, string subtitle, string message)
            {
                API.SetNotificationTextEntry("STRING");
                API.AddTextComponentString(message);
                API.SetNotificationMessage(picture, picture, true, icon, title, subtitle);
            }

            public static void DrawRect(float x, float y, float width, float height, int r, int g, int b, int a)
            {
                Minimap anchor = MinimapAnchor.GetMinimapAnchor();
                API.DrawRect(anchor.LeftX + x + (width / 2), anchor.BottomY - y + (height / 2), width, height, r, g, b, a);
            }

            /// <summary>
            /// Show a chat message to the client.
            /// </summary>
            public static void DisplayChatMessage(string text) => TriggerEvent("chat:addMessage", text);

            /// <summary>
            /// Returns if the HUD is hidden.
            /// </summary>
            public static bool IsHudHidden => API.IsHudHidden();

            /// <summary>
            /// Returns if the Radar is hidden.
            /// </summary>
            public static bool IsRadarHidden => API.IsRadarHidden();
        }
    }
}