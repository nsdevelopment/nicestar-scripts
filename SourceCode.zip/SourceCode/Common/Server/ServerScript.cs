﻿using System;
using System.Collections.Generic;
using System.Linq;
using CitizenFX.Core;

namespace NS.Fivem.Common.Server
{
    public abstract class ServerScript : BaseScript
    {
        /// <summary>
        /// CallbackHandler dictionary for Client->Server callbacks
        /// </summary>
        protected internal CallbackHandlerDictionary CallbackHandlers { get; protected set; } = new CallbackHandlerDictionary();

        /// <summary>
        /// Triggers a specific callback onto a specifc client
        /// </summary>
        /// <param name="player">The player to trigger the event/callback for</param>
        /// <param name="guid">The GUID of the registered callback</param>
        /// <param name="args">Any other arguments</param>
        public void ReturnClientCallback(Player player, string guid, params object[] args)
        {
            player.TriggerEvent($"NScommon:client:internalcallback:{guid}", guid, args);
        }

        /// <summary>
        /// Triggers a callback on a client, that can be returned in-line on the server
        /// </summary>
        /// <param name="player">The player to trigger the callback on</param>
        /// <param name="eventName">The name of the event to trigger on the client</param>
        /// <param name="action">The Delegate or Func that will be invoked on return from the client</param>
        /// <param name="args">Any arguments to be passed to server event</param>
        public void TriggerClientCallback(Player player, string eventName, Delegate action, params object[] args)
        {
            string guid = RegisterCallbackInternal(action);
            player.TriggerEvent(eventName, guid, args);
        }

        /// <summary>
        /// Internal method, registers a Delegate as a callback
        /// </summary>
        internal string RegisterCallbackInternal(Delegate action)
        {
            string guid = Guid.NewGuid().ToString();
            CallbackHandlers[guid] += action;
            EventHandlers.Add($"NScommon:server:internalcallback:{guid}", new Action<string, List<object>>(ReceiveInternalCallback));
            return guid;
        }

        /// <summary>
        /// This function will be added at run-time as an event handler for the server to call, should not be called directly.
        /// </summary>
        internal async void ReceiveInternalCallback(string guid, List<object> args)
        {
            await CallbackHandlers[guid].Invoke(args.ToArray());
            CallbackHandlers[guid].Destroy();
            CallbackHandlers.Remove(guid);
            EventHandlers.Remove($"NScommon:server:internalcallback:{guid}");
        }



        /// <summary>
        /// [BEST] - Gets the R* license identifier (Social Club account)
        /// </summary>
        /// <param name="p">Player to get the identifier for.</param>
        /// <returns>String of the license identifier, if present, or an empty string</returns>
        public static string GetLicenseId(Player p) => GetId(p, "license:");

        /// <summary>
        /// [GOOD] - Gets the Discord identifier. Discord must be open and FiveM must be authorized.
        /// </summary>
        /// <param name="p">Player to get the identifier for.</param>
        /// <returns>String of the Discord identifier, if present, or an empty string</returns>
        public static string GetDiscordId(Player p) => GetId(p, "discord:");

        /// <summary>
        /// [POOR] - Gets the Steam identifier. Steam must be open.
        /// </summary>
        /// <param name="p">Player to get the identifier for.</param>
        /// <returns>String of the Steam identifier, if present, or an empty string</returns>
        public static string GetSteamId(Player p) => GetId(p, "steam:");
        
        /// <summary>
        /// [GOOD] - Gets the Xbox Live identifier. Xbox Live account must be actived.
        /// </summary>
        /// <param name="p">Player to get the identifier for.</param>
        /// <returns>String of the Xbox Live identifier, if present, or an empty string</returns>
        public static string GetXblId(Player p) => GetId(p, "xbl:");

        /// <summary>
        /// [GOOD] - Gets the Xbox identifier. Xbox App must be logged in.
        /// Unknown if the Xbox app must be running. Also known as the Passport Unique Identifier (Xbox account without Xbox Live activated)
        /// </summary>
        /// <param name="p">Player to get the identifier for.</param>
        /// <returns>String of the Xbox identifier, if present, or an empty string</returns>
        public static string GetLiveId(Player p) => GetId(p, "live:");

        private static string GetId(Player p, string idPrefix)
        {
            string id = "";
            if (p != null && p.Identifiers != null)
            {
                id = p.Identifiers.Where(x => x.StartsWith(idPrefix))
                    .Select(x => x.Replace(idPrefix, "")).FirstOrDefault();

                if (string.IsNullOrWhiteSpace(id))
                {
                    id = "";
                }
            }

            return id;
        }
    }
}
