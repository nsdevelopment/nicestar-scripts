﻿using CitizenFX.Core;

namespace NS.Fivem.Common.Server
{
    public static class Extensions
    {
        #region Player Extensions
        /// <summary>
        /// [BEST] - Get the R* identified of this player. Also known as the Social Club identifier.
        /// </summary>
        /// <param name="player"></param>
        /// <returns>String of the R* identifier, if present, or an empty string.</returns>
        public static string GetLicenseId(this Player player) => ServerScript.GetLicenseId(player);

        /// <summary>
        /// [GOOD] - Get the Discord identified of this player.
        /// </summary>
        /// <param name="player"></param>
        /// <returns>String of the Discord identifier, if present, or an empty string.</returns>
        public static string GetDiscordId(this Player player) => ServerScript.GetDiscordId(player);

        /// <summary>
        /// [POOR] - Get the Steam identified of this player.
        /// </summary>
        /// <param name="player"></param>
        /// <returns>String of the Steam identifier, if present, or an empty string.</returns>
        public static string GetSteamId(this Player player) => ServerScript.GetSteamId(player);

        /// <summary>
        /// [BETTER] - Get the Xbox Live identified of this player. Xbox Live account must be actived.
        /// </summary>
        /// <param name="player"></param>
        /// <returns>String of the Xbox Live identifier, if present, or an empty string.</returns>
        public static string GetXblId(this Player player) => ServerScript.GetXblId(player);

        /// <summary>
        /// [BETTER] - Gets the Xbox identifier of this player. Xbox App must be logged in.
        /// Unknown if the Xbox app must be running. Also known as the Passport Unique Identifier (Xbox account without Xbox Live activated)
        /// </summary>
        /// <param name="player"></param>
        /// <returns>String of the Xbox Live identifier, if present, or an empty string.</returns>
        public static string GetLiveId(this Player player) => ServerScript.GetLiveId(player);
        #endregion
    }
}
