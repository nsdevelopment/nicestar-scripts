﻿using CitizenFX.Core;

namespace NS.Fivem.Common.Server
{
    public static class DebugDev
    {
        public static void Write(string data)
        {
#if DEBUG
            Debug.Write(data);
#endif
        }

        public static void Write(string format, params object[] args) => Write(string.Format(format, args));

        public static void WriteLine() => Write("\n");

        public static void WriteLine(string data) => Write(data + "\n");

        public static void WriteLine(string format, params object[] args) => Write(string.Format(format, args) + "\n");
    }
}
