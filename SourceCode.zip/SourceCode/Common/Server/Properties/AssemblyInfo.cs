﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Common.Server")]
[assembly: Guid("40af5588-f4a2-4729-b421-fd46b696e44f")]

