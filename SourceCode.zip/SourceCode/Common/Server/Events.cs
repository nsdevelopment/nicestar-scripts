﻿using CitizenFX.Core;
using CitizenFX.Core.Native;

namespace NS.Fivem.Common.Server
{
    public class Events : BaseScript
    {
        [EventHandler(Event.Server.DEBUG_LOG)]
        internal void OnDebugLog(string msg) => DebugDev.WriteLine(msg);

        [EventHandler(Event.Server.LOG)]
        internal void OnLog(string msg) => Debug.WriteLine(msg);

        [EventHandler(Event.Server.DROP_PLAYER)]
        internal void OnDropPlayer(string playerHandle, string reason = "No reason specified.") => API.DropPlayer(playerHandle, reason);
    }
}
